# NCAA football — November 10, 2026
Bovada event API captured 7:25 a.m. CT. Three games, nine markets, both frozen Week8+ champion and continuous challenger.
Verified positive EV 0. Provisional positive EV 0. No bets qualify.
First same-day NCAAFB capture. New/improved/reduced/removed status cannot be certified against a prior same-day run.
| CT | Away at home | Away spread / home spread | Away ML / home ML | Total Over / Under | Champion / Challenger |
|---|---|---|---|---|---|
| 6 p.m. | Kent State at Bowling Green | +5.5 -110 / -5.5 -110 | +176 / -215 | 44 -108 / -112 | Pass / Pass |
| 6 p.m. | Western Michigan at Akron | -14.5 -108 / +14.5 -112 | -650 / +475 | 48.5 -112 / -108 | Pass / Pass |
| 7 p.m. | Ohio at Miami Ohio | -1.5 -110 / +1.5 -110 | -120 / +100 | 46.5 -108 / -112 | Pass / Pass |
No eligible model probability, EV or Full Kelly assigned outside the supported regimes. Adjusted Kelly unavailable. Week11 inputs include completed Week10 games through Nov7.
