# NCAA football — Nov10 all available main-market quotes

Bovada API captured Nov10 07:38 CT. 3 today games, 64 future games. 5 verified positive-EV unique wagers, 2 provisional research unders. 0 newly crossed positive certified, 7 unable to compare against an earlier same-day snapshot.

## Today — all Pass in champion and challenger

EventID,KickoffCT,Away,Home,CapturedUTC,AwaySpread,AwaySpreadOdds,HomeSpread,HomeSpreadOdds,AwayML,HomeML,Total,OverOdds,UnderOdds,DateGroup
33272564,2026-11-10T18:00:00-06:00,Kent State,Bowling Green,2026-11-10T13:38:19.420583+00:00,5.5,-110,-5.5,-110,+176,-215,44.0,-108,-112,Today
33270593,2026-11-10T18:00:00-06:00,Western Michigan,Akron,2026-11-10T13:38:19.420583+00:00,-14.5,-108,14.5,-112,-650,+475,48.5,-112,-108,Today
33271379,2026-11-10T19:00:00-06:00,Ohio,Miami Ohio,2026-11-10T13:38:19.420583+00:00,-1.5,-110,1.5,-110,-120,EVEN,46.5,-108,-112,Today


## Future positive-EV wagers

Away,Home,KickoffCT,Selection,Market,Line,Odds,ChampionModel,ChallengerModel,Tier,P,EV,FullKelly,AdjustedKelly,AdjustedKellyStatus,Evidence,PriorLine,PriorOdds,PriorEV,DeltaStatus,CapturedUTC,PriorCapturedUTC,PriorSnapshotUsage
UL Lafayette,UL Monroe,2026-11-12T20:00:00-06:00,UL Monroe,ML,,340.0,EXISTING-W8PLUS-ML-UNCHANGED,SHARED-ML-COMPONENT; no distinct ML challenger adopted,A existing,0.2356262283171441,0.0367554045954343,0.0108104131163042,,Unavailable; exposure unreconciled,Verified Positive EV,,340.0,0.0367554045954343,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
East Carolina,Charlotte,2026-11-14T12:00:00-06:00,Charlotte,ML,,365.0,EXISTING-W8PLUS-ML-UNCHANGED,SHARED-ML-COMPONENT; no distinct ML challenger adopted,A existing,0.2231114953138515,0.0374684532094098,0.0102653296464136,,Unavailable; exposure unreconciled,Verified Positive EV,,370.0,0.0370850181709248,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
Kansas State,TCU,2026-11-14T13:00:00-06:00,Kansas State,ML,,300.0,EXISTING-W8PLUS-ML-UNCHANGED,SHARED-ML-COMPONENT; no distinct ML challenger adopted,A existing,0.2576850121459619,0.0307400485838478,0.0102466828612826,,Unavailable; exposure unreconciled,Verified Positive EV,,300.0,0.0307400485838478,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
California,Virginia,2026-11-14T14:30:00-06:00,California,ML,,340.0,EXISTING-W8PLUS-ML-UNCHANGED,SHARED-ML-COMPONENT; no distinct ML challenger adopted,A existing,0.2356262283171441,0.0367554045954343,0.0108104131163042,,Unavailable; exposure unreconciled,Verified Positive EV,,340.0,0.0367554045954343,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
Florida Atlantic,Tulsa,2026-11-14T14:30:00-06:00,Under,Total,74.0,-105.0,EXISTING-OU-RESEARCH-UNCHANGED,SHARED-OU-RESEARCH; no distinct current total challenger adopted,Lean,0.5454545454545454,0.0649350649350648,0.0681818181818181,0.0,Research allocation 0%,Provisional Positive EV,74.5,-112.0,0.0324675324675323,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
San Jose State,Air Force,2026-11-14T18:00:00-06:00,San Jose State,ML,,370.0,EXISTING-W8PLUS-ML-UNCHANGED,SHARED-ML-COMPONENT; no distinct ML challenger adopted,A existing,0.2206563868448776,0.0370850181709248,0.0100229778840337,,Unavailable; exposure unreconciled,Verified Positive EV,,370.0,0.0370850181709248,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only
North Texas,UTSA,2026-11-14T20:00:00-06:00,Under,Total,76.5,-108.0,EXISTING-OU-RESEARCH-UNCHANGED,SHARED-OU-RESEARCH; no distinct current total challenger adopted,Lean,0.5454545454545454,0.0505050505050503,0.0545454545454544,0.0,Research allocation 0%,Provisional Positive EV,77.0,-112.0,0.0324675324675323,UNVERIFIED CHANGE — no prior same-day future-game snapshot,2026-11-10T13:38:19.420583+00:00,2026-11-09T19:06:20.786365+00:00,Nov9 prices shown for reference only


## Scoring limitations

ML frozen rule and shared challenger; research Under rule 54/99 retains zero allocation. Current exposure unreconciled, adjusted portfolio Kelly unavailable. No spread qualifies. Full quote board and negative/Pass scores included.