# Gambling — rolling authoritative quote and score history

**Updated:** 2026-11-11 06:51 UTC

This is the authoritative *observed Bovada quote / frozen model-scoring history*.
It does **not** supersede the separate sport-specific model training authorities,
and wager settlement/P&L remains authoritative only in reconciled Bovada transactions.

## Current coverage

- 28 preserved capture batches; 39 time cohorts (max 120 seconds between earliest and latest capture).
- 1156 Bovada listings, 1155 actual physical games.
- 6936 main-line side records, including missing ML offers and Passes.
- 10173 model score records (champion/challenger independently): {"Challenger only": 3, "PASS": 9495, "PRODUCTION_QUALIFIED": 191, "Pass": 112, "Qualified secondary": 3, "RESEARCH_POSITIVE_EV": 197, "Track only": 2, "UNSCORED": 170}.
- Game-level coverage and explicitly `UNSCORED` matchups: {"ALL_PASS": 828, "HAS_PRODUCTION_QUALIFIER": 173, "RESEARCH_ONLY_OR_PASS": 119, "UNSCORED": 35}.
- 81 settled games, 0 joined wagers (not inferred).

## Cohorts and parlay timing

The Nov 6 full capture spanned **17 min 56.1 sec**, so it is **not** one synchronized snapshot.
The `quote_cohorts` table groups captured observations whose maximum-minus-minimum
timestamp is at most 120s (the research default; adjustable for later batches).
For parlays, also require every leg to have an `OFFERED_PREGAME` quote with a posted
odds price, retain **one selection per physical game**, and check that the line
was still available in the bookmaker when the multi-leg bet would be submitted.
Quote timestamps are *fetch observation times*, not proven line-posted times.

## Data lineage / guardrails

`market_quotes` keeps each home/away ML, spread, and Over/Under offer, including
`NOT_OFFERED`, `NOT_PREGAME` and `SPECIAL_NON_GAME`. `model_scores` keeps every
available model result, including source `Pass` rows, with probability/EV/Kelly
left null where they were unavailable. Every score has its source row JSON and
SHA-256. Exact `scored_at_utc` exists only when the source had a frozen/scored
timestamp; otherwise it stays null (`NOT_RECORDED`). The separate `model_probability_asof_utc`
tracks NHL's frozen morning V15 probabilities.

**NHL:** Only three Nov 6 matchups had defensibly reproducible V15 + approximate
Day0 probabilities; remaining physical games retain quotes but no score row.
The Day0 probabilities are explicitly reconstructed from rounded older EV and
are research-only. No NHL production wagering authorization is assumed.

**Adjusted Kelly:** Raw numeric values remain as recorded; the companion status
identifies legacy NCAABB V4 evidence-factor sizing, NBA shadow dependencies, or
unavailable/nonvalidated joint Kelly. Missing probabilities are not modeled as 50%.

## Append workflow

1. Save a new Bovada price capture with per-event `quote_captured_utc` and original
   source JSON, as well as every model/Pass scoring record with the frozen version.
2. Normalize that batch to the JSON structure in the included canonical Nov6 import.
   Give it a **new unique `batch_id`**. Include cohorts from actual quote capture times.
3. Run `python build_rolling_scoring_history.py --previous-archive    GAMBLING_ROLLING_AUTHORITATIVE_QUOTES_AND_SCORES.zip --import-json NEW_BATCH.json`.
4. Validate exported row counts, quote joins, status coverage, time windows and
   SQLite integrity. Replace the **same** saved authoritative archive version;
   don't create a separate conflicting rolling authority.

Tables: `capture_batches`, `quote_cohorts`, `events`, `market_quotes`,
`model_scores`, `game_scoring_coverage` (read-only coverage view),
`source_files`, `settlements`, `wager_links`.

Do not overwrite prior predictions with later re-scores: append the new quote batch.
Do not retrospectively add bet settlements from a prediction; join against the
reconciled Bovada wager transaction ID only when verified.

## November 11 append and November 10 finals

New Nov11 snapshot: 41 games, 246 main-market sides, 289 model score records. ESPN Nov10: 85 finals, 67 matched to archived Bovada games, 67 new settlement keys. Sizing for unquoted parlays remains blocked.
The files `exports/quote_outcomes.csv` and `exports/model_score_outcomes.csv` are counterfactual grading of quotes, **not** real ticket returns.
