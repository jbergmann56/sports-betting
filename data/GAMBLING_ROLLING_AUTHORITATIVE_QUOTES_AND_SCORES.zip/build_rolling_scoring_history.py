"""Append-only, quote-time-aware Bovada scoring ledger for five sports.

The initial seed normalizes the saved 2026-11-06 five-sport source bundle.
Subsequent runs accept --import-json containing canonical batch/event/score data
and --previous-archive to preserve all earlier quote and score observations.

No result or wager is inferred. This is a pregame research/scoring ledger, not
the reconciled transactional P&L authority.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import sqlite3
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs" / "rolling_scoring_history"
BATCH_ID = "FIVE_SPORT_20261106_AFTERNOON_V1"
COHORT_MAX_SECONDS = 120
SOURCE_SNAPSHOT_LIBRARY_ID = "libfile_e29af8b136d88191abedf5c2d96588f8"

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS capture_batches (
 batch_id TEXT PRIMARY KEY, source_name TEXT NOT NULL,
 min_quote_utc TEXT NOT NULL, max_quote_utc TEXT NOT NULL,
 quote_skew_seconds REAL NOT NULL, coherent_all_sports INTEGER NOT NULL,
 cohort_max_seconds INTEGER NOT NULL, source_snapshot_library_id TEXT,
 ingested_utc TEXT NOT NULL, notes TEXT
);
CREATE TABLE IF NOT EXISTS quote_cohorts (
 cohort_id TEXT PRIMARY KEY, batch_id TEXT NOT NULL,
 min_quote_utc TEXT NOT NULL, max_quote_utc TEXT NOT NULL,
 quote_skew_seconds REAL NOT NULL, sports_json TEXT NOT NULL,
 physical_games INTEGER NOT NULL, FOREIGN KEY (batch_id) REFERENCES capture_batches(batch_id)
);
CREATE TABLE IF NOT EXISTS events (
 batch_id TEXT NOT NULL, sport TEXT NOT NULL, event_id TEXT NOT NULL,
 game_key TEXT NOT NULL, game TEXT NOT NULL, away TEXT NOT NULL, home TEXT NOT NULL,
 start_utc TEXT, quote_captured_utc TEXT NOT NULL, quote_cohort_id TEXT NOT NULL,
 pregame_quote INTEGER NOT NULL, physical_game INTEGER NOT NULL,
 bovada_url TEXT, raw_board_json TEXT NOT NULL,
 PRIMARY KEY(batch_id,sport,event_id),
 FOREIGN KEY(batch_id) REFERENCES capture_batches(batch_id),
 FOREIGN KEY(quote_cohort_id) REFERENCES quote_cohorts(cohort_id)
);
CREATE TABLE IF NOT EXISTS market_quotes (
 quote_id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, sport TEXT NOT NULL,
 event_id TEXT NOT NULL, game_key TEXT NOT NULL, quote_cohort_id TEXT NOT NULL,
 quote_captured_utc TEXT NOT NULL, market TEXT NOT NULL, period TEXT NOT NULL,
 side TEXT NOT NULL, line REAL, odds_american REAL, break_even_probability REAL,
 quote_status TEXT NOT NULL, source_file TEXT NOT NULL, source_sha256 TEXT NOT NULL,
 FOREIGN KEY(batch_id,sport,event_id) REFERENCES events(batch_id,sport,event_id)
);
CREATE TABLE IF NOT EXISTS model_scores (
 score_id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, sport TEXT NOT NULL,
 event_id TEXT NOT NULL, game_key TEXT NOT NULL, quote_cohort_id TEXT NOT NULL,
 quote_captured_utc TEXT NOT NULL, scored_at_utc TEXT,
 scored_time_provenance TEXT NOT NULL, model_probability_asof_utc TEXT,
 market TEXT NOT NULL, selection_side TEXT, selection_display TEXT,
 quote_id TEXT, quoted_line REAL, quoted_odds REAL,
 model_role TEXT NOT NULL, model_version TEXT NOT NULL, tier TEXT,
 model_probability REAL, model_probability_provenance TEXT,
 expected_value REAL, full_kelly REAL, adjusted_kelly REAL,
 adjusted_kelly_status TEXT, production_authorized INTEGER NOT NULL,
 action_status TEXT NOT NULL, pass_or_block_reason TEXT,
 model_health TEXT, source_file TEXT NOT NULL, source_sha256 TEXT NOT NULL,
 source_row_json TEXT NOT NULL,
 FOREIGN KEY(batch_id,sport,event_id) REFERENCES events(batch_id,sport,event_id),
 FOREIGN KEY(quote_id) REFERENCES market_quotes(quote_id)
);
CREATE TABLE IF NOT EXISTS source_files (
 batch_id TEXT NOT NULL, source_name TEXT NOT NULL, file_sha256 TEXT NOT NULL,
 source_library_id TEXT, PRIMARY KEY(batch_id,source_name),
 FOREIGN KEY(batch_id) REFERENCES capture_batches(batch_id)
);
CREATE TABLE IF NOT EXISTS settlements (
 game_key TEXT NOT NULL, sportsbook_event_id TEXT,
 final_away_score REAL, final_home_score REAL, settled_at_utc TEXT,
 result_source TEXT, PRIMARY KEY(game_key)
);
CREATE TABLE IF NOT EXISTS wager_links (
 wager_id TEXT NOT NULL, score_id TEXT NOT NULL, linked_at_utc TEXT NOT NULL,
 basis TEXT NOT NULL, PRIMARY KEY(wager_id,score_id),
 FOREIGN KEY(score_id) REFERENCES model_scores(score_id)
);
CREATE INDEX IF NOT EXISTS idx_quote_time ON market_quotes(quote_captured_utc,sport);
CREATE INDEX IF NOT EXISTS idx_cohort_market ON market_quotes(quote_cohort_id,market);
CREATE INDEX IF NOT EXISTS idx_scores_status ON model_scores(sport,model_role,action_status);
CREATE INDEX IF NOT EXISTS idx_scores_cohort ON model_scores(quote_cohort_id,action_status);
CREATE VIEW IF NOT EXISTS game_scoring_coverage AS
 SELECT e.batch_id, e.sport, e.event_id, e.game_key, e.game,
        e.start_utc, e.quote_captured_utc, e.quote_cohort_id,
        e.pregame_quote, e.physical_game,
        COUNT(s.score_id) AS model_score_rows,
        CASE WHEN COUNT(s.score_id)=0 THEN 'UNSCORED'
             WHEN SUM(CASE WHEN s.action_status='PRODUCTION_QUALIFIED' THEN 1 ELSE 0 END)>0
                  THEN 'HAS_PRODUCTION_QUALIFIER'
             WHEN SUM(CASE WHEN s.action_status='RESEARCH_POSITIVE_EV' THEN 1 ELSE 0 END)>0
                  THEN 'RESEARCH_ONLY_OR_PASS'
             ELSE 'ALL_PASS' END AS game_status
 FROM events e LEFT JOIN model_scores s
   ON e.batch_id=s.batch_id AND e.sport=s.sport AND e.event_id=s.event_id
 GROUP BY e.batch_id,e.sport,e.event_id;
"""


def text_or_none(x):
    if x is None or str(x).strip().lower() in ("", "nan", "none", "null", "nat"):
        return None
    return str(x).strip()


def number(x):
    s = text_or_none(x)
    if s is None:
        return None
    try:
        n = float(s)
        return n if math.isfinite(n) else None
    except ValueError:
        return None


def truth(x):
    return str(x).strip().lower() in ("true", "1", "yes")


def parse_time(x):
    return dt.datetime.fromisoformat(str(x).replace("Z", "+00:00")).astimezone(dt.timezone.utc)


def iso(x):
    return parse_time(x).isoformat().replace("+00:00", "Z")


def digest(x):
    return hashlib.sha256(x.encode("utf-8")).hexdigest()[:24]


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def break_even(odds):
    o = number(odds)
    if o is None or o == 0:
        return None
    return 100 / (o + 100) if o > 0 else abs(o) / (abs(o) + 100)


def market_key(m):
    return {"ML": "Moneyline", "Total": "Total", "Spread": "Spread", "Moneyline": "Moneyline"}[m]


def side_from_selection(selection, game_row, market):
    sel = (selection or "").strip().lower()
    if not sel:
        return None
    if market == "Total":
        return "Over" if sel.startswith("over") else "Under" if sel.startswith("under") else None
    for key, name in (("Away", game_row["away"]), ("Home", game_row["home"])):
        if sel == name.lower() or sel.startswith(name.lower() + " ") or sel.startswith(name.lower() + "+"):
            return key
    return None


def seed_nov6(root):
    # Raw public Bovada board is the price authority, not the model-selected price.
    boards = {}
    sha = {}
    for sport in ("NCAABB", "NBA", "NHL", "NFL", "NCAAFB"):
        name = f"{sport}_main_board_20261106.csv"
        boards[sport] = read_csv(root / name)
        sha[name] = file_sha(root / name)

    nfl_abbrevs = read_csv(root / "models/nfl/snapshot/quotes.csv")
    nfl_by_abbrev = {(x["away"], x["home"]): (x["away_name"], x["home_name"]) for x in nfl_abbrevs}
    sources = [
        "NCAABB_V4_live_scores_20261106.csv",
        "NCAABB_V5_live_opportunities_20261106.csv",
        "NBA_R4_R3_current_20261106/production/forecasts.csv",
        "NBA_R4_R3_current_20261106/R3_challenger/forecasts.csv",
        "models/nfl_refresh/scoring/dual_model_bet_sheet.csv",
        "NCAAFB_current_rescored_20261106.csv",
        "outputs/five_sport_20261106/NHL_V15_DAY0_RESEARCH_20261106.csv",
    ]
    for src in sources:
        sha[src] = file_sha(root / src)

    event_by_id = {}
    event_by_game = {}
    events = []
    for sport, rows in boards.items():
        for row in rows:
            physical = not (sport == "NHL" and row["game"] == "Away Goals @ Home Goals")
            captured = iso(row["captured_utc"])
            try:
                valid_start = parse_time(row["start_utc"]) > parse_time(captured)
            except Exception:
                valid_start = False
            pregame = physical and truth(row["pregame"]) and not truth(row["live"]) and valid_start
            entry = {
                "batch_id": BATCH_ID, "sport": sport, "event_id": str(row["event_id"]),
                "game_key": f"{sport}:BOVADA:{row['event_id']}", "game": row["game"],
                "away": row["away"], "home": row["home"], "start_utc": iso(row["start_utc"]),
                "quote_captured_utc": captured, "pregame_quote": int(pregame),
                "physical_game": int(physical), "bovada_url": row["bovada_url"],
                "raw_board_json": json.dumps(row, sort_keys=True),
            }
            events.append(entry)
            event_by_id[(sport, entry["event_id"])] = entry
            event_by_game[(sport, row["game"])] = entry

    # Close each cohort before adding a quote more than 120s from its first quote.
    groups = []
    for entry in sorted(events, key=lambda x: (x["quote_captured_utc"], x["sport"], x["event_id"])):
        stamp = parse_time(entry["quote_captured_utc"])
        if not groups or (stamp - parse_time(groups[-1][0]["quote_captured_utc"])).total_seconds() > COHORT_MAX_SECONDS:
            groups.append([])
        groups[-1].append(entry)
    cohorts = []
    for i, group in enumerate(groups, 1):
        c = f"{BATCH_ID}:COHORT:{i:03d}"
        times = [parse_time(x["quote_captured_utc"]) for x in group]
        for entry in group:
            entry["quote_cohort_id"] = c
        cohorts.append({
            "cohort_id": c, "batch_id": BATCH_ID,
            "min_quote_utc": min(times).isoformat().replace("+00:00", "Z"),
            "max_quote_utc": max(times).isoformat().replace("+00:00", "Z"),
            "quote_skew_seconds": (max(times) - min(times)).total_seconds(),
            "sports_json": json.dumps(sorted({x["sport"] for x in group if x["physical_game"]})),
            "physical_games": sum(x["physical_game"] for x in group),
        })

    quotes = []
    quote_index = {}
    for sport, rows in boards.items():
        name = f"{sport}_main_board_20261106.csv"
        for row in rows:
            event = event_by_id[(sport, str(row["event_id"]))]
            definitions = (
                ("Moneyline", "Away", None, "away_ml_odds"),
                ("Moneyline", "Home", None, "home_ml_odds"),
                ("Spread", "Away", "away_spread_line", "away_spread_odds"),
                ("Spread", "Home", "home_spread_line", "home_spread_odds"),
                ("Total", "Over", "total_line", "over_odds"),
                ("Total", "Under", "total_line", "under_odds"),
            )
            for market, side, line_col, odds_col in definitions:
                o = number(row[odds_col]); line = number(row[line_col]) if line_col else None
                qid = digest("|".join((BATCH_ID, sport, str(row["event_id"]), market, side, "main")))
                quote = {
                    "quote_id": qid, "batch_id": BATCH_ID, "sport": sport,
                    "event_id": str(row["event_id"]), "game_key": event["game_key"],
                    "quote_cohort_id": event["quote_cohort_id"],
                    "quote_captured_utc": event["quote_captured_utc"],
                    "market": market, "period": "Full game", "side": side,
                    "line": line, "odds_american": o, "break_even_probability": break_even(o),
                    "quote_status": ("SPECIAL_NON_GAME" if not event["physical_game"] else
                                     "NOT_OFFERED" if o is None else
                                     "NOT_PREGAME" if not event["pregame_quote"] else "OFFERED_PREGAME"),
                    "source_file": name, "source_sha256": sha[name],
                }
                quotes.append(quote)
                quote_index[(sport, str(row["event_id"]), market, side)] = quote

    scores = []

    def score(event, source, src_row, *, market, side, role, version, tier=None,
              model_p=None, p_origin=None, ev=None, full=None, adjusted=None,
              adjusted_status=None, authorized=False, status=None, reason=None,
              model_health=None, scored_at=None, probability_asof=None,
              selection=None, selected_odds=None, selected_line=None):
        market = market_key(market)
        quote = quote_index.get((event["sport"], event["event_id"], market, side))
        if quote is None:
            quote_ref = None
        else:
            quote_ref = quote["quote_id"] if quote["odds_american"] is not None else None
            if selected_odds is not None and quote["odds_american"] is not None and abs(float(selected_odds)-quote["odds_american"]) > .02:
                raise ValueError(f"Model/source odds mismatch: {event['game']}, {market}, {side}: {selected_odds} vs {quote['odds_american']}")
        if status is None:
            status = "PRODUCTION_QUALIFIED" if authorized else "PASS"
        row = {
            "score_id": digest("|".join(map(str, (BATCH_ID,event["sport"],event["event_id"],market,side,role,version)))),
            "batch_id": BATCH_ID, "sport": event["sport"], "event_id": event["event_id"],
            "game_key": event["game_key"], "quote_cohort_id": event["quote_cohort_id"],
            "quote_captured_utc": event["quote_captured_utc"],
            "scored_at_utc": iso(scored_at) if scored_at else None,
            "scored_time_provenance": "MODEL_EXPLICIT" if scored_at else "NOT_RECORDED",
            "model_probability_asof_utc": iso(probability_asof) if probability_asof else None,
            "market": market, "selection_side": side, "selection_display": selection,
            "quote_id": quote_ref, "quoted_line": selected_line if selected_line is not None else (quote["line"] if quote else None),
            "quoted_odds": selected_odds if selected_odds is not None else (quote["odds_american"] if quote else None),
            "model_role": role, "model_version": version, "tier": text_or_none(tier),
            "model_probability": number(model_p), "model_probability_provenance": p_origin,
            "expected_value": number(ev), "full_kelly": number(full),
            "adjusted_kelly": number(adjusted), "adjusted_kelly_status": adjusted_status,
            "production_authorized": int(authorized), "action_status": status,
            "pass_or_block_reason": text_or_none(reason), "model_health": text_or_none(model_health),
            "source_file": source, "source_sha256": sha[source],
            "source_row_json": json.dumps(src_row, sort_keys=True),
        }
        if authorized and (not event["pregame_quote"] or quote_ref is None):
            raise ValueError(f"Unauthorized pregame/missing quote recommendation: {event['game']} {market}")
        scores.append(row)

    # NCAABB V4 (one selected side per scored game/market, all Pass rows).
    src = "NCAABB_V4_live_scores_20261106.csv"
    for r in read_csv(root / src):
        e = event_by_id[("NCAABB", r["game_id"].replace("BOVADA_", ""))]
        market = market_key(r["market"]); side = r["selected_side"]
        eligible = r["tier"] in ("A", "B+", "B") and truth(r["stake_eligible"]) and (number(r["expected_unit_net_at_quote"]) or 0) > 0
        score(e,src,r,market=market,side=side,role="CHAMPION",version="NCAABB_V4_FROZEN",
              tier=r["tier"], model_p=r["selected_probability"],p_origin="SOURCE_MODEL_FROZEN",
              ev=r["expected_unit_net_at_quote"],full=r["full_kelly"],
              adjusted=r["final_recommended_kelly"],
              adjusted_status="LEGACY_EVIDENCE_FACTOR_NOT_JOINT_PORTFOLIO_KELLY",
              authorized=eligible,status="PRODUCTION_QUALIFIED" if eligible else "PASS",
              reason=r["pricing_status"] if not eligible else "",model_health=r["health"],
              selected_odds=number(r["quoted_odds"]))

    # NCAABB V5 prospective side-level shadow. 326 priced sides incl Pass.
    src = "NCAABB_V5_live_opportunities_20261106.csv"
    for r in read_csv(root / src):
        e = event_by_id[("NCAABB",r["game_id"].replace("BOVADA_", ""))]
        research = r["shadow_research_tier"] == "Lean" and (number(r["shadow_ev"]) or 0) > 0
        score(e,src,r,market=r["market"],side=r["side"],role="CHALLENGER",
              version="NCAABB_V5_PROSPECTIVE_SHADOW",tier=r["shadow_research_tier"],
              model_p=r["shadow_p"],p_origin="SOURCE_SHADOW_PROBABILITY",
              ev=r["shadow_ev"],full=r["shadow_full_kelly"],
              adjusted=r["shadow_adjusted_kelly"],adjusted_status=r["shadow_adjusted_kelly_status"],
              status="RESEARCH_POSITIVE_EV" if research else "PASS",
              reason="Research only; promotion unvalidated" if research else "V5 Pass",
              selected_odds=number(r["offered_odds"]))

    # NBA R4/R3, all 27 decisions each, including blank EV/Model_P Passes.
    for lane,role in (("production","CHAMPION"),("R3_challenger","CHALLENGER")):
        src = f"NBA_R4_R3_current_20261106/{lane}/forecasts.csv"
        for r in read_csv(root / src):
            e = event_by_game[("NBA",r["Game"])]
            market = market_key(r["Market"])
            side = side_from_selection(r["Selection"],json.loads(e["raw_board_json"]),market)
            qualifying = r["Tier"] in ("A","B+","B") and (number(r["EV"]) or 0)>0
            status = ("PRODUCTION_QUALIFIED" if role=="CHAMPION" else "RESEARCH_POSITIVE_EV") if qualifying else "PASS"
            score(e,src,r,market=market,side=side,role=role,version=r["Release"],
                  tier=r["Tier"],model_p=r["Model_P"],p_origin="SOURCE_MODEL_IF_GRADED",
                  ev=r["EV"],full=r["Full_Kelly"],adjusted=r["Adjusted_Kelly"],
                  adjusted_status=r["Adjusted_Kelly_Status"],authorized=status=="PRODUCTION_QUALIFIED",
                  status=status,reason=r["Reason"],model_health=r["Model_Health"],
                  scored_at=r["Frozen_UTC"],selection=r["Selection"],selected_odds=number(r["Odds"]))

    # NFL champion/challenger are separate rows; inactive challenger side stays NULL.
    src = "models/nfl_refresh/scoring/dual_model_bet_sheet.csv"
    for r in read_csv(root / src):
        away,home = nfl_by_abbrev[(r["away"],r["home"])]
        e = event_by_game[("NFL",f"{away} @ {home}")]
        market = market_key(r["market"])
        for role,which in (("CHAMPION","champion"),("CHALLENGER","challenger")):
            select = r[which+"_selection"]
            if market=="Total":side = select.title() if select.lower() in ("over","under") else None
            elif select == r["away"]:side="Away"
            elif select == r["home"]:side="Home"
            else:side=None
            ev=number(r[which+"_ev"])
            positive=ev is not None and ev>0
            qualifying = positive and ((role=="CHAMPION" and r["champion_tier"] in ("A","B+")) or role=="CHALLENGER")
            status=("PRODUCTION_QUALIFIED" if role=="CHAMPION" else "RESEARCH_POSITIVE_EV") if qualifying else "PASS"
            score(e,src,r,market=market,side=side,role=role,
                  version=r["champion_version"] if role=="CHAMPION" else r["challenger_version"],
                  tier=r["champion_tier"] if role=="CHAMPION" else r["challenger_rule"],
                  model_p=r[which+"_p"],p_origin="SOURCE_MODEL_IF_GRADED",
                  ev=ev,full=r[which+"_full_kelly"],
                  adjusted=r["adjusted_kelly"] if role=="CHAMPION" else None,
                  adjusted_status="UNAVAILABLE_NOT_VALIDATED",authorized=status=="PRODUCTION_QUALIFIED",
                  status=status,reason=r[which+"_action"],model_health=r["input_status"],
                  selection=select,selected_odds=number(r[which+"_odds"]),selected_line=number(r[which+"_line"]))

    # NCAAFB existing A ML production; provisional spreads and totals research.
    src = "NCAAFB_current_rescored_20261106.csv"
    for r in read_csv(root / src):
        e = event_by_id[("NCAAFB",r["EventID"])]
        market=market_key(r["Market"])
        side=side_from_selection(r["Selection"],json.loads(e["raw_board_json"]),market)
        for role,which in (("CHAMPION","Champion"),("CHALLENGER","Challenger")):
            ev=number(r[which+"EV"])
            prod = role=="CHAMPION" and truth(r["ProductionAuthorized"]) and ev is not None and ev>0
            research = not prod and ev is not None and ev>0 and r[which+"Tier"]!="Pass"
            status="PRODUCTION_QUALIFIED" if prod else "RESEARCH_POSITIVE_EV" if research else "PASS"
            score(e,src,r,market=market,side=side,role=role,
                  version=r["champion_version"] if role=="CHAMPION" else r["challenger_version"],
                  tier=r[which+"Tier"],model_p=r[which+"P"],p_origin="SOURCE_MODEL_IF_GRADED",
                  ev=ev,full=r[which+"FullKelly"],adjusted_status="UNAVAILABLE_NOT_VALIDATED",
                  authorized=prod,status=status,reason=r["Reason"],model_health=r["ModelHealth"],
                  selection=r["Selection"],selected_odds=number(r["Odds"]),selected_line=number(r["Line"]))

    # NHL has verified repriced outcomes only for 3 physical games; other 10
    # physical games remain quotes-only/UNSCORED (never fabricated as Pass).
    src = "outputs/five_sport_20261106/NHL_V15_DAY0_RESEARCH_20261106.csv"
    for r in read_csv(root / src):
        e = event_by_game[("NHL",r["Game"])]
        for role,p,ev,full,version,p_origin in (
            ("CHALLENGER",r["V15_P"],r["V15_EV"],r["V15_Full_Kelly"],"NHL_V15_FROZEN_MORNING","FROZEN_MORNING_VERIFIED"),
            ("RESEARCH_BASELINE",r["Day0_Approx_P"],r["Day0_Approx_EV"],r["Day0_Approx_Full_Kelly"],"NHL_DAY0_APPROX_FROM_ROUNDED_EV","INFERRED_FROM_ROUNDED_MORNING_EV"),
        ):
            positive=(number(ev) or 0)>0
            score(e,src,r,market="Total",side="Under",role=role,version=version,
                  tier=r["V15_Tier"] if role=="CHALLENGER" else "Research baseline",
                  model_p=p,p_origin=p_origin,ev=ev,full=full,
                  adjusted_status="UNAVAILABLE_NOT_VALIDATED",status="RESEARCH_POSITIVE_EV" if positive else "PASS",
                  reason="No NHL production wagering authorization; push probability not separately verified",
                  probability_asof=r["Model_Probabilities_AsOf"],
                  selection=f"Under {r['Line']}",selected_odds=number(r["Current_Under_Odds"]),
                  selected_line=number(r["Line"]))

    times=[parse_time(x["quote_captured_utc"]) for x in events]
    batch={
        "batch_id":BATCH_ID,"source_name":"Saved five-sport Bovada Nov 6 afternoon scoring capture",
        "min_quote_utc":min(times).isoformat().replace("+00:00","Z"),
        "max_quote_utc":max(times).isoformat().replace("+00:00","Z"),
        "quote_skew_seconds":(max(times)-min(times)).total_seconds(),
        "coherent_all_sports":int((max(times)-min(times)).total_seconds()<=COHORT_MAX_SECONDS),
        "cohort_max_seconds":COHORT_MAX_SECONDS,
        "source_snapshot_library_id":SOURCE_SNAPSHOT_LIBRARY_ID,
        "ingested_utc":dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00","Z"),
        "notes":"Source captures are asynchronous. Cohorts <=120s per window; do not assume all lines were simultaneously available or still posted. No wagers placed.",
    }
    return {"batch":batch,"cohorts":cohorts,"events":events,"market_quotes":quotes,
            "model_scores":scores,
            "source_files":[{"batch_id":BATCH_ID,"source_name":k,"file_sha256":v,
                             "source_library_id":SOURCE_SNAPSHOT_LIBRARY_ID} for k,v in sha.items()]}


def insert_rows(db,table,rows):
    if not rows:return
    fields=list(rows[0]); q=','.join('?' for _ in fields)
    stmt=f"INSERT OR IGNORE INTO {table} ({','.join(fields)}) VALUES ({q})"
    for x in rows:
        if set(x)!=set(fields):raise ValueError(f"Nonconforming {table} row: {x}")
    db.executemany(stmt,[[r[k] for k in fields] for r in rows])


def write_export(db,table,path):
    q=db.execute(f"SELECT * FROM {table}")
    with path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow([x[0] for x in q.description]);wr.writerows(q.fetchall())


def load_previous(archive,target):
    if not archive:return False
    with zipfile.ZipFile(archive) as z:
        if "GAMBLING_ROLLING_SCORING_HISTORY.sqlite" not in z.namelist():
            raise ValueError("Previous archive has no canonical SQLite history")
        with z.open("GAMBLING_ROLLING_SCORING_HISTORY.sqlite") as source, target.open("wb") as sink:
            shutil.copyfileobj(source,sink)
    return True


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--seed-nov6',action='store_true',help='Import the saved, fully timestamped November 6 slate')
    ap.add_argument('--import-json',type=Path,help='New normalized batch JSON using the frozen schema')
    ap.add_argument('--previous-archive',type=Path,help='Prior authoritative ZIP to append; do not discard previous runs')
    ap.add_argument('--output-dir',type=Path,default=OUTPUT)
    args=ap.parse_args()
    if not args.seed_nov6 and not args.import_json:ap.error('Supply --seed-nov6 and/or --import-json')
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    dbpath=out/'GAMBLING_ROLLING_SCORING_HISTORY.sqlite'
    if args.previous_archive:
        # Safe guarded update: preserve prior observations and fail on batch ID conflicts.
        existing=out/'_previous_scoring_history.sqlite'
        load_previous(args.previous_archive,existing)
        shutil.copyfile(existing,dbpath)
        existing.unlink()
    elif dbpath.exists():
        # A local pre-existing DB counts as a rolling update, not a reset.
        pass
    db=sqlite3.connect(dbpath)
    db.executescript(SCHEMA)
    batches=[]
    if args.seed_nov6:batches.append(seed_nov6(ROOT))
    if args.import_json:batches.append(json.loads(args.import_json.read_text()))
    for data in batches:
        ident=data['batch']['batch_id']
        saved=db.execute('SELECT batch_id FROM capture_batches WHERE batch_id=?',(ident,)).fetchone()
        if saved:
            print(f"SKIPPED pre-existing immutable batch: {ident}")
            continue
        with db:
            insert_rows(db,'capture_batches',[data['batch']])
            for table,key in (("quote_cohorts","cohorts"),("events","events"),
                              ("market_quotes","market_quotes"),("model_scores","model_scores"),
                              ("source_files","source_files")):
                insert_rows(db,table,data[key])
        print(f"ADDED {ident}: {len(data['events'])} listings, {len(data['market_quotes'])} quoted sides, {len(data['model_scores'])} model rows")
        (out/f"{ident}_CANONICAL_IMPORT.json").write_text(json.dumps(data,indent=2,ensure_ascii=False))

    # Avoid retaining a transient WAL; checkpoint to the standalone SQLite file.
    db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
    tables=('capture_batches','quote_cohorts','events','market_quotes','model_scores','game_scoring_coverage','source_files','settlements','wager_links')
    exports=out/'exports';exports.mkdir(exist_ok=True)
    counts={}
    for table in tables:
        counts[table]=db.execute(f'SELECT count(*) FROM {table}').fetchone()[0]
        write_export(db,table,exports/f'{table}.csv')
    statuses=dict(db.execute('SELECT action_status,count(*) FROM model_scores GROUP BY action_status'))
    game_statuses=dict(db.execute('SELECT game_status,count(*) FROM game_scoring_coverage WHERE physical_game=1 GROUP BY game_status'))
    sports=dict(db.execute('SELECT sport,count(*) FROM events WHERE physical_game=1 GROUP BY sport'))
    cohorts=[dict(zip(('cohort_id','min_utc','max_utc','skew_seconds','sports','physical_games'),x))
             for x in db.execute('SELECT cohort_id,min_quote_utc,max_quote_utc,quote_skew_seconds,sports_json,physical_games FROM quote_cohorts ORDER BY min_quote_utc')]
    assert counts['model_scores'] and counts['market_quotes']
    integrity=db.execute('PRAGMA integrity_check').fetchone()[0]
    fk=db.execute('PRAGMA foreign_key_check').fetchall()
    assert integrity=='ok' and not fk,(integrity,fk)
    metadata={"format_version":"1.0","canonical_database":"GAMBLING_ROLLING_SCORING_HISTORY.sqlite",
              "counts":counts,"score_statuses":statuses,"game_statuses":game_statuses,"physical_games_by_sport":sports,
              "cohorts":cohorts,"integrity_check":integrity,"foreign_key_violations":len(fk),
              "cohort_threshold_seconds":COHORT_MAX_SECONDS,
              "business_rules":["Append only; never retrospectively overwrite model predictions or odds",
                "Every main-line side retained, including missing prices and nonpregame observations",
                "Source Passes stay Pass, not zero EV; quote-only games remain UNSCORED",
                "One leg per physical game for parlay selection; same cohort <=120s is necessary, not sufficient, for simultaneous availability",
                "P&L authority is reconciled Bovada transaction history, not quote/score ledger"]}
    (out/'MANIFEST.json').write_text(json.dumps(metadata,indent=2))
    now=dt.datetime.now(dt.timezone.utc)
    readme=f"""# Gambling — rolling authoritative quote and score history

**Updated:** {now:%Y-%m-%d %H:%M} UTC

This is the authoritative *observed Bovada quote / frozen model-scoring history*.
It does **not** supersede the separate sport-specific model training authorities,
and wager settlement/P&L remains authoritative only in reconciled Bovada transactions.

## Current coverage

- {counts['capture_batches']} preserved capture batches; {counts['quote_cohorts']} time cohorts (max {COHORT_MAX_SECONDS} seconds between earliest and latest capture).
- {counts['events']} Bovada listings, {sum(sports.values())} actual physical games.
- {counts['market_quotes']} main-line side records, including missing ML offers and Passes.
- {counts['model_scores']} model score records (champion/challenger independently): {json.dumps(statuses,sort_keys=True)}.
- Game-level coverage and explicitly `UNSCORED` matchups: {json.dumps(game_statuses,sort_keys=True)}.
- {counts['settlements']} settled games, {counts['wager_links']} joined wagers (not inferred).

## Cohorts and parlay timing

The Nov 6 full capture spanned **17 min 56.1 sec**, so it is **not** one synchronized snapshot.
The `quote_cohorts` table groups captured observations whose maximum-minus-minimum
timestamp is at most {COHORT_MAX_SECONDS}s (the research default; adjustable for later batches).
For parlays, also require every leg to have an `OFFERED_PREGAME` quote with a posted
odds price, retain **one selection per physical game**, and check that the line
was still available in the bookmaker when the multi-leg bet would be submitted.
Quote timestamps are *fetch observation times*, not proven line-posted times.

## Data lineage / guardrails

`market_quotes` keeps each home/away ML, spread, and Over/Under offer, including
`NOT_OFFERED`, `NOT_PREGAME` and `SPECIAL_NON_GAME`. `model_scores` keeps every
available model result, including source `Pass` rows, with probability/EV/Kelly
left null where they were unavailable. Every score has its source row JSON and
SHA-256. Exact `scored_at_utc` exists only when the source had a frozen/scored
timestamp; otherwise it stays null (`NOT_RECORDED`). The separate `model_probability_asof_utc`
tracks NHL's frozen morning V15 probabilities.

**NHL:** Only three Nov 6 matchups had defensibly reproducible V15 + approximate
Day0 probabilities; remaining physical games retain quotes but no score row.
The Day0 probabilities are explicitly reconstructed from rounded older EV and
are research-only. No NHL production wagering authorization is assumed.

**Adjusted Kelly:** Raw numeric values remain as recorded; the companion status
identifies legacy NCAABB V4 evidence-factor sizing, NBA shadow dependencies, or
unavailable/nonvalidated joint Kelly. Missing probabilities are not modeled as 50%.

## Append workflow

1. Save a new Bovada price capture with per-event `quote_captured_utc` and original
   source JSON, as well as every model/Pass scoring record with the frozen version.
2. Normalize that batch to the JSON structure in the included canonical Nov6 import.
   Give it a **new unique `batch_id`**. Include cohorts from actual quote capture times.
3. Run `python build_rolling_scoring_history.py --previous-archive \
   GAMBLING_ROLLING_AUTHORITATIVE_QUOTES_AND_SCORES.zip --import-json NEW_BATCH.json`.
4. Validate exported row counts, quote joins, status coverage, time windows and
   SQLite integrity. Replace the **same** saved authoritative archive version;
   don't create a separate conflicting rolling authority.

Tables: `capture_batches`, `quote_cohorts`, `events`, `market_quotes`,
`model_scores`, `game_scoring_coverage` (read-only coverage view),
`source_files`, `settlements`, `wager_links`.

Do not overwrite prior predictions with later re-scores: append the new quote batch.
Do not retrospectively add bet settlements from a prediction; join against the
reconciled Bovada wager transaction ID only when verified.
"""
    (out/'README.md').write_text(readme)
    db.close()
    archive=out/'GAMBLING_ROLLING_AUTHORITATIVE_QUOTES_AND_SCORES.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in (dbpath,out/'README.md',out/'MANIFEST.json',Path(__file__)):
            z.write(p,p.name)
        for p in sorted(exports.glob('*.csv')):
            z.write(p,'exports/'+p.name)
        for p in sorted(out.glob('*_CANONICAL_IMPORT.json')):
            z.write(p,'canonical_batches/'+p.name)
    print(json.dumps({'archive':str(archive),'manifest':metadata},indent=2))


if __name__=='__main__':
    main()
