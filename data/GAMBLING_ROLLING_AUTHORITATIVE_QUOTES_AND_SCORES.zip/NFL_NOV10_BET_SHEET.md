# NFL bet sheet — November 10, 2026
Quote: November 10 07:27:12 CST, Bovada NFL API. No NFL games scheduled Nov10; this is the upcoming Week10 board.
All15 Week9 results complete, including TB24-CHI27 and BUF23-MIN6. Models unchanged. SRS/PPG through Week9; four-snapshot SRS endpoint W9 minus W6.
12 games/36 markets/72 model observations scored; all passes retained. BUF-NYJ and MIN-GB incomplete: not scored.
Verified positive EV:1 unique (reproducible quote and champion calculation; not proof of profitability).
Provisional/research positive EV:1 unique. Newly crossed-positive:0 established. Improved/reduced/removed: not assessable. Unable to compare with same-day run:2 positives.
No prior Nov10 NFL snapshot. Both positive selections are FIRST SEEN / UNVERIFIED CHANGE.
| Matchup/time Central | Selection | Model/role | Tier/segment | Model P | EV | Full Kelly | Adjusted Kelly | Prior same-day line/EV |
|---|---|---|---|---|---|---|---|---|
| LAC at BAL, Nov16 7:15pm | Baltimore -5 (-110) | NFL-v1.1-REV2-CAL-2026-10-24 champion | A |52.5307%|+0.2859%|0.3145%|Unavailable; sizing blocked|N/A|
| JAX at TEN, Nov15 noon | Tennessee ML +400 | NFL-W8-FULL-SLOPE-2026-10-26 challenger, research only |higher-slope dog >=+400|23.5212%|+17.6059%|4.4015%|Unavailable; sizing blocked|N/A|
Champion negative EV qualifiers: NE+3(-117) A -2.57%; CLE+5(-112) A -0.57%; JAX-TEN U46(-108) B+ -0.96%. All pass.
No model promotion, recalibration, wagers or P&L inferred. Full Kelly shown standalone; no joint scenario distribution/open-exposure inputs for Adjusted Kelly.
