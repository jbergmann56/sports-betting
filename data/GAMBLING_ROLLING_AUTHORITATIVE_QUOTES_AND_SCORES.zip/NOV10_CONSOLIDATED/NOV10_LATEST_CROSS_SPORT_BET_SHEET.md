# November 10, 2026 — latest cross-sport Bovada model scoring

**Latest captured cohorts:** NCAA basketball 7:26:10 a.m. CST (master's later quote capture); NBA 7:26:48 CST, NHL 7:26:48–55 CST (individual event quote capture). These are not a perfectly simultaneous market snapshot; prices can move. NFL/NCAAFB have no November 10 scheduled games.

**Coverage:** 56 NCAA basketball, six NBA, seven NHL games. All 69 games have timestamped main-line quotes. NCAA basketball's later run has 12 model-qualified champion observations; NBA has one. **One NCAA moneyline observation is held due contradictory model-side calibration**, leaving 12 nonconflicted model qualifiers (two selections are on one Georgia State game; they are not independent bets). NHL positive-EV rows are research-only, not production.

## Most recent nonconflicted champion qualifiers (not instructions to wager)

| Sport | Game | Selection | Price | Tier | EV | Full Kelly | Adjusted Kelly | Delta |
|---|---|---|---:|---|---:|---:|---:|---|
| NCAABB | Georgia State @ Fresno State | Georgia State ML | +205 | B | +9.42% | 4.59% | 3.53% | Existing |
| NCAABB | Wisconsin Green Bay @ Northern Iowa | Wisconsin Green Bay ML | +150 | B | +8.09% | 5.39% | 4.14% | Existing |
| NCAABB | Washington State @ Duquesne | Washington State ML | +135 | B | +7.14% | 5.29% | 4.06% | Existing |
| NCAABB | Texas State @ UT Rio Grande Valley | UT Rio Grande Valley +6.5 | -105 | B+ | +6.84% | 7.18% | 6.51% | Existing |
| NCAABB | Detroit U @ Xavier | Detroit U +32 | -110 | B | +4.27% | 4.92% | 4.46% | Added |
| NBA | Miami Heat @ Utah Jazz | Utah Jazz +9 | -110 | B | +4.21% | 4.64% | 4.64% | Current Latest |
| NCAABB | Georgia State @ Fresno State | Georgia State +5.5 | -105 | B | +3.62% | 3.80% | 3.47% | Existing |
| NCAABB | Presbyterian @ NC State | Presbyterian +19 | -105 | B | +3.48% | 3.80% | 3.47% | Added |
| NCAABB | Bryant @ Providence | Providence -30.5 | -110 | B | +2.17% | 2.39% | 2.28% | Added |
| NCAABB | Alcorn State @ Murray State | Murray State -28.5 | -110 | B | +2.17% | 2.39% | 2.28% | Existing |
| NCAABB | Creighton @ Kansas State | Creighton -3 | -110 | B | +2.10% | 2.39% | 2.28% | Existing |
| NCAABB | Duke (#2) @ Michigan State (#6) | Duke (#2) ML | -300 | B | +1.78% | 5.35% | 5.08% | Existing |

## Model conflict — HOLD

| Sport | Game | Selection | Price | Tier | EV | Full Kelly | Adjusted Kelly | Delta |
|---|---|---|---:|---|---:|---:|---:|---|
| NCAABB | UT Martin @ Arkansas State | UT Martin ML | +215 | B | +9.47% | 4.40% | 3.38% | Added |

In an earlier 7:24:35 a.m. CST V4 champion-family score, **Arkansas State moneyline −300** (against UT Martin) was positive EV **+1.78%**. In the newer 7:26:10 a.m. CST V4 champion-family classification, **UT Martin moneyline +215** qualified at **+9.47%**. The labels of the two frozen implementations differ (V4_FROZEN vs. V4_THROUGH2025); their mutually exclusive probabilities are not coherent as one unified model. Both sides must be held from actionable model recommendations until calibration, version parity, and side mapping are audited.

## Changes from 7:24:35 to 7:26:10 college-basketball scoring

**Added or changed:** Bryant @ Providence — Providence -30.5, Detroit U @ Xavier — Detroit U +32, Presbyterian @ NC State — Presbyterian +19, UT Martin @ Arkansas State — UT Martin ML.

**No longer qualified in newest run:** Bucknell @ Virginia (#9) — Home Spread, Loyola Marymount @ Troy — Home Moneyline, UT Martin @ Arkansas State — Home Moneyline.

Note that some changes arise from changed input/verification eligibility, not necessarily from shifting book lines; new/dropped is a *model-classification delta*, not proof of market movement.

## Previous-day settlement and all-game archive

November 9: 39 official finals verified, six college-basketball matches unresolved, zero fabricated results. Five prior-day champion-qualified hypothetical wagers: one Win / four Losses, sum **−3.667 units** assuming equal one-unit stakes. This is **not actual bet P&L**. The consolidated rolling master-derived archive keeps both quote snapshots (including all Passes), plus verified November 8–9 outcomes, with 22 capture batches, 924 event listings, 5,544 quote sides and 7,694 model scores. Adjusted Kelly in NCAA basketball remains a legacy evidence factor, not posterior-aware joint-portfolio Kelly.
