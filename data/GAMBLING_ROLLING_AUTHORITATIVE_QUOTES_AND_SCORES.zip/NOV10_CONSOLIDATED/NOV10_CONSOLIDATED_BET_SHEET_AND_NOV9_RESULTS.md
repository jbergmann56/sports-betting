# Bovada consolidated bet sheet — November 10, 2026

**Quote capture:** college basketball 07:24:35 CST; NBA/NHL 07:26:48–07:26:55 CST. These are two distinct cohorts ~2m13s apart, *not one synchronized cross-sport snapshot*.

**Coverage:** 69 pregame games: 56 NCAABB, 6 NBA, 7 NHL, 0 NFL, 0 NCAAFB. 544 scored model classifications: 12 qualified, 15 research-only, 517 Pass. Eight college basketball listings have prices saved but missing verified input parity; their model scores are unscored, not fabricated Passes. Adjusted Kelly is model-specific and in CBB is a **legacy evidence factor, not validated joint portfolio Kelly**. NHL is research only. An NFL or NCAAFB game is not omitted—it is absent from today's schedule.

## Twelve production-qualified selections (not betting instructions)

| Sport | Game | Selection | Odds | Model / tier | EV | Full Kelly | Adjusted Kelly |
|---|---|---|---:|---|---:|---:|---:|
| NCAABB | Georgia State @ Fresno State | Georgia State ML | +215 | CHAMPION B | +9.47% | 4.40% | 3.38% |
| NCAABB | Washington State @ Duquesne | Washington State ML | +160 | CHAMPION B | +8.66% | 5.41% | 4.15% |
| NCAABB | Wisconsin Green Bay @ Northern Iowa | Wisconsin Green Bay ML | +145 | CHAMPION B | +7.78% | 5.37% | 4.12% |
| NCAABB | Texas State @ UT Rio Grande Valley | UT Rio Grande Valley +6.5 | -105 | CHAMPION B+ | +6.84% | 7.18% | 6.51% |
| NCAABB | Loyola Marymount @ Troy | Troy ML | +100 | CHAMPION B | +5.25% | 5.25% | 4.03% |
| NBA | Miami Heat @ Utah Jazz | Utah Jazz +9 | -110 | CHAMPION B | +4.21% | 4.64% | 4.64% |
| NCAABB | Georgia State @ Fresno State | Georgia State +6 | -105 | CHAMPION B | +3.48% | 3.80% | 3.47% |
| NCAABB | Alcorn State @ Murray State | Murray State -28.5 | -110 | CHAMPION B | +2.17% | 2.39% | 2.28% |
| NCAABB | Bucknell @ Virginia (#9) | Virginia (#9) -37.5 | -110 | CHAMPION B | +2.17% | 2.39% | 2.28% |
| NCAABB | Creighton @ Kansas State | Creighton -3 | -110 | CHAMPION B | +2.10% | 2.39% | 2.28% |
| NCAABB | Duke (#2) @ Michigan State (#6) | Duke (#2) ML | -300 | CHAMPION B | +1.78% | 5.35% | 5.08% |
| NCAABB | UT Martin @ Arkansas State | Arkansas State ML | -300 | CHAMPION B | +1.78% | 5.35% | 5.08% |

## Challenger and research-only positive-EV observations

| Sport | Game | Selection | Odds | Model / tier | EV | Full Kelly | Adjusted Kelly |
|---|---|---|---:|---|---:|---:|---:|
| NBA | Los Angeles Clippers @ Phoenix Suns | Los Angeles Clippers +3.5 | -105 | CHALLENGER B | +6.58% | 6.91% | 6.91% |
| NCAABB | Duke (#2) @ Michigan State (#6) | Michigan State (#6) +6.5 | -110 | CHALLENGER Lean | +4.11% | 4.52% | — |
| NCAABB | Illinois (#3) @ Texas Tech (#19) | Texas Tech (#19) +2.5 | -110 | CHALLENGER Lean | +4.11% | 4.52% | — |
| NCAABB | Kansas (#17) @ Kentucky (#23) | Kentucky (#23) +4.5 | -110 | CHALLENGER Lean | +4.11% | 4.52% | — |
| NCAABB | Virginia Tech @ Iowa | Iowa -5 | -110 | CHALLENGER Lean | +4.11% | 4.52% | — |
| NCAABB | Florida (#1) @ Florida State | Florida State +9.5 | -115 | CHALLENGER Lean | +1.96% | 2.25% | — |
| NHL | Detroit Red Wings @ St. Louis Blues | Over | +100 | CHAMPION Lean (unapproved research) | +1.52% | 1.71% | — |
| NHL | Florida Panthers @ Columbus Blue Jackets | Over | +100 | CHAMPION Lean (unapproved research) | +1.52% | 1.71% | — |
| NHL | Nashville Predators @ Los Angeles Kings | Over | -120 | CHAMPION Lean (unapproved research) | +1.07% | 1.44% | — |
| NHL | New Jersey Devils @ Winnipeg Jets | Over | -120 | CHAMPION Lean (unapproved research) | +1.07% | 1.44% | — |
| NHL | Washington Capitals @ Ottawa Senators | Over | -120 | CHAMPION Lean (unapproved research) | +1.07% | 1.44% | — |
| NCAABB | UT Martin @ Arkansas State | Arkansas State ML | -300 | CHALLENGER Lean | +0.92% | 2.77% | — |
| NCAABB | Washington State @ Duquesne | Duquesne ML | -185 | CHALLENGER Lean | +0.47% | 0.86% | — |
| NCAABB | Georgia State @ Fresno State | Fresno State ML | -260 | CHALLENGER Lean | +0.44% | 1.15% | — |
| NHL | New Jersey Devils @ Winnipeg Jets | New Jersey Devils ML | -150 | CHAMPION Lean (unapproved research) | +0.04% | 0.06% | — |

These are not production-approved opportunities. All unselected scored rows are in the full CSV. Same-game double exposure (Georgia State spread and ML) must not be treated as independent parlay legs.

## November 9 official finals joined to yesterday's quotes

39 Nov9 listed games were matched to ESPN final scores: 27 NCAABB, 8 NBA, 3 NHL and 1 NFL. Six additional quoted NCAABB games remain unmatched and are *not* counted as losses or wins. Of five Nov9 champion-qualified **hypothetical one-unit wagers**, 1 won and 4 lost; the illustrative sum is **-3.667 units**, assuming one equal unit on every selection. This is **not placed-wager or transactional P&L**.

The **recovery ZIP** contains 10 capture batches, 616 event listings, 3,696 quote sides, 4,650 model score rows, 81 game settlements, and 570 graded quote sides. Every graded model row—including Passes—can be joined via `model_score_outcomes.csv`. The persistent master is **not yet updated**: its latest Library version (v11) downloaded as a truncated, invalid ZIP. This intact recovery fork derives from the last locally verified version (v7), pending reconciliation. One Charlotte/Seton Hall sportsbook home-away discrepancy was reconciled by team identity. Source: ESPN game-score feeds.

## College basketball input-blocked games

- Detroit U @ Xavier — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- MD Eastern Shore @ Boston College — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- South Alabama @ Central Florida — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- Evansville @ Middle Tennessee State — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- Nicholls State @ Tulane  — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- SE Louisiana @ Mississippi — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- Arkansas Little Rock @ New Mexico — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED
- Queens NC @ BYU (#25) — BLOCKED: NO_VERIFIED_D1_PRIOR; ESPN_PAIR_UNVERIFIED

All 69 games' main-line quotes remain in the historical archive even where a model could not be scored. The November 9 six unmatched finals are separately retained as unresolved. No wagers were placed by this run. All twelve production-qualified November 10 selections are new slate games relative to November 9; this is not a verified intraday line-change comparison.
