from pathlib import Path
import sys,json,numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;BASE=ROOT/'model'
sys.path.insert(0,str(BASE/'src'))
from reconstruction import team_features
from analyze import prepare,predict
from segments import indicators
from core import score,payout,kelly
from apply_calibration import probability

raw=pd.read_csv(ROOT/'games_snapshot.csv');raw=raw[raw.game_type=='REG']
for col in ['away_team','home_team']:raw[col]=raw[col].replace({'OAK':'LV','SD':'LAC','STL':'LA'})
completed=raw[raw.away_score.notna()&raw.home_score.notna()&(raw.season==2026)&(raw.week<10)&(raw.gameday<'2026-11-12')]
week9=raw[(raw.season==2026)&(raw.week==9)];ncomplete=int((week9.away_score.notna()&week9.home_score.notna()&(week9.gameday<'2026-11-12')).sum());ready=ncomplete==len(week9)==15
status='FINAL' if ready else 'PROVISIONAL'
features=team_features(completed,2026,10,{})
pd.DataFrame(features.values()).to_csv(ROOT/'team_features.csv',index=False)
cfg=json.load(open(BASE/'data/champion_config_preserved.json'));models=json.load(open(BASE/'results/primary2018__reconstructed__frozen_models.json'))
board=json.load(open(ROOT/'board.json'));rows=[];sides=[]
for a,h,*v in board:
    fa,fh=features[a],features[h];line,ao,ho,am,hm,total,oo,uo=v
    for r in score(a,h,*v,fa['srs'],fh['srs'],fa['off'],fh['off'],10):
        p=None;mlanchor=None
        if r['tier'] in ['A','B+']:
            if r['market']=='Moneyline':
                selected=am if r['selection']==a else hm;other=hm if r['selection']==a else am
                x,y=1/(1+payout(selected)),1/(1+payout(other));mlanchor=x/(x+y)
            p=probability(cfg,r['market'],10,mlanchor)
        ev=p*payout(r['odds'])-(1-p) if p is not None else np.nan
        rows.append(dict(away=a,home=h,market=r['market'],champion_selection=r['selection'],champion_line=r['line'],champion_odds=r['odds'],champion_tier=r['tier'],champion_signal=r['signal'],champion_projection=r['model_projection'],champion_p=p,champion_ev=ev,champion_full_kelly=kelly(p,r['odds']) if p is not None else np.nan,adjusted_kelly=np.nan,champion_action='POSITIVE EV' if pd.notna(ev) and ev>0 else 'PASS',input_status=status))
    for market,o1,o2 in [('Spread',ho,ao),('Moneyline',hm,am),('Total',oo,uo)]:
        p1=1/(1+payout(o1));p2=1/(1+payout(o2));p1/=p1+p2
        for sign,odds,anchor in [(1,o1,p1),(-1,o2,1-p1)]:
            off=sign*(fa['off_slope']+fh['off_slope']);defense=sign*(fa['defense_slope']+fh['defense_slope'])
            rel=(off+defense)/2 if market=='Total' else sign*(fh['srs_slope']-fa['srs_slope'])
            gap=sign*(fa['off']+fh['off']-total) if market=='Total' else sign*(fh['srs']-fa['srs']+1.5-line)
            sides.append(dict(game_id=a+'_'+h,season=2026,week=10,away=a,home=h,market=market,sign=sign,selection=('Over' if sign==1 else 'Under') if market=='Total' else h if sign==1 else a,odds=odds,anchor=anchor,canonical_anchor=p1,line=total if market=='Total' else -sign*line if market=='Spread' else np.nan,total=total,rel=rel,own=fh['srs_slope'] if sign==1 else fa['srs_slope'],off=off,defense=defense,gap=gap,canonical_y=np.nan,y=np.nan,profit=np.nan,feature_cutoff_week=9))
side=pd.DataFrame(sides);side.to_csv(ROOT/'both_side_inputs.csv',index=False);chall=[]
for market,d in side.groupby('market'):
    d,h,a=prepare(d);f=models[market];candidates={}
    for name in f['selected_rules']:
        m=f['models'][name];C,S=indicators(d,m['rule'],m['thresholds']);ph=predict(h,C,S,m['slope'])
        for i in np.flatnonzero(S):
            sign=S[i];p=ph[i] if sign>0 else 1-ph[i];r=(h if sign>0 else a).iloc[i];ev=p*payout(r.odds)-(1-p)
            record=dict(away=r.away,home=r.home,market=market,challenger_selection=r.selection,challenger_line=r.line,challenger_odds=r.odds,challenger_rule=name,challenger_p=p,challenger_ev=ev,challenger_full_kelly=kelly(p,r.odds),challenger_action='SHADOW POSITIVE EV' if ev>0 else 'PASS - NONPOSITIVE EV',challenger_relative_slope=r.rel)
            key=(r.away,r.home)
            if key not in candidates or ev>candidates[key]['challenger_ev']:candidates[key]=record
    chall.extend(candidates.values())
out=pd.DataFrame(rows).merge(pd.DataFrame(chall,columns=['away','home','market','challenger_selection','challenger_line','challenger_odds','challenger_rule','challenger_p','challenger_ev','challenger_full_kelly','challenger_action','challenger_relative_slope']),on=['away','home','market'],how='left')
out.challenger_action=out.challenger_action.fillna('PASS - NO SELECTED SEGMENT')
out['champion_version']='REV2-CAL';out['challenger_version']='NFL-W8-FULL-SLOPE-2026-10-26';out['challenger_status']='RESEARCH - NOT PRODUCTION'
out.to_csv(ROOT/'dual_model_bet_sheet.csv',index=False)
json.dump(dict(week=10,season=2026,week9_complete=ncomplete,week9_scheduled=len(week9),input_status=status,source_prices='Bovada API full-game main quote snapshot; raw payload provenance in ../snapshot/feed_metadata.json',champion='REV2-CAL',challenger='Full-history primary2018 reconstructed nested policy; not the earlier linear or production-regime challenger',show_both_models_on_future_boards=True,adjusted_kelly=None,adjusted_reason='Joint predictive distribution and existing exposure amounts unavailable',checks=dict(games=len(board)>0,markets=len(out)==3*len(board),both_sides=len(side)==6*len(board),no_scoring_week_inputs=side.feature_cutoff_week.lt(side.week).all().item())),open(ROOT/'metadata.json','w'),indent=2)
print(out[(out.champion_action=='POSITIVE EV')|out.challenger_p.notna()][['away','home','market','champion_selection','champion_line','champion_odds','champion_p','champion_ev','champion_full_kelly','challenger_selection','challenger_line','challenger_p','challenger_ev','challenger_full_kelly','challenger_action']].round(6).to_string(index=False))
print('ALL CHAMPION QUALIFIERS\n',out[out.champion_tier.isin(['A','B+'])][['away','home','market','champion_selection','champion_line','champion_odds','champion_p','champion_ev','champion_full_kelly','champion_action']].round(6).to_string(index=False))
